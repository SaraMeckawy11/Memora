## Memora Landing Page — Refined Builder Prompt (GSAP)

**Project:** Memora — premium photo book creation web app.

---

### 🎨 Design System

**Aesthetic:** Minimal-Elegant Brutalism — Swiss editorial × luxury stationery.

**Color Palette (Light Mode):**
```
--background:   #F7F5F2
--surface:      #EDEAE5
--border:       #1A1A1A
--text-primary: #0F0F0F
--text-muted:   #6B6560
--accent:       #C8A882
--accent-dark:  #8B6F4E
--ink:          #1A1A1A
```

**Fonts — Google Fonts (uncommon, distinctive):**
```html
<link href="https://fonts.googleapis.com/css2?
  family=Cormorant+Garamond:ital,wght@0,300;0,400;1,300;1,400&
  family=Syne:wght@400;500;700;800&
  family=Azeret+Mono:wght@400;500&
  display=swap" rel="stylesheet">
```
- **Display/Hero:** `Cormorant Garamond` — ultra-refined, high-contrast serif. Italic 300 for headlines. Feels like a luxury fashion brand.
- **Body/UI:** `Syne` — geometric grotesque with character. Unusual rhythm, not overused.
- **Labels/Numbers:** `Azeret Mono` — sharp, technical mono. For step tags, prices, small badges.

---

### 📐 Layout Rules
- Max-width: `1280px`
- Spacing unit: `8px` multiples
- Section dividers: `1px solid #1A1A1A` full-width borders
- Cards: `border: 1.5px solid #1A1A1A`, `border-radius: 0`, offset shadow `4px 4px 0 #1A1A1A`
- No drop shadows — only offset block shadows

---

### 🏗️ Page Sections

**1. Navbar**
- Left: `MEMORA` — Cormorant Garamond italic, 20px
- Right: nav links in Syne 13px + `[Create your book →]` black square CTA
- Sticky, border-bottom `1px solid #1A1A1A`
- GSAP: `gsap.from(".nav", { y: -60, opacity: 0, duration: 0.8, ease: "power3.out" })`

---

**2. Hero Section**
- **Left (55%):**
  - Label: `[ PRESERVE YOUR MEMORIES ]` — Azeret Mono 11px, tracking 0.25em
  - H1 three lines, Cormorant Garamond 80px:
    > *"Your memories,"*
    > *"beautifully"*
    > *"bound."* — mix italic + upright per line
  - Subtext: Syne 17px, muted
  - CTAs: `Start Creating` (black fill) + `See examples →` (text link)

- **Right (45%):**
  - Spline 3D embed `{/* SPLINE_EMBED_HERE */}`

- **Below hero fold — Full-bleed image strip:**
  ```
  [wedding photo] [travel photo] [family photo] [birthday photo]
  ```
  Horizontal row, each image `300×400px`, object-fit cover, `1.5px` border separating each. No border-radius.
  - Use Unsplash direct URLs:
    ```
    https://images.unsplash.com/photo-1519741497674-611481863552?w=600  (wedding)
    https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=600  (travel)
    https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=600  (family)
    https://images.unsplash.com/photo-1530103862676-de8c9debad1d?w=600  (birthday)
    ```
  - GSAP: horizontal marquee loop with `gsap.to()` infinite x scroll

---

**3. How It Works — 3 Steps**
- Background: `#EDEAE5`
- 3 brutalist cards side by side
- Step number: Azeret Mono 96px, color `#C8A882`, top-left of card
- Title: Syne 700 22px
- Description: Syne 400 15px muted
- Small image inside each card (process screenshot/mockup):
  ```
  https://images.unsplash.com/photo-1606761568499-6d2451b23c66?w=400 (uploading/phone)
  https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400 (designing/laptop)
  https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400 (delivery/box)
  ```
- GSAP ScrollTrigger:
  ```js
  gsap.from(".step-card", {
    scrollTrigger: { trigger: ".steps-section", start: "top 75%" },
    y: 60, opacity: 0, duration: 0.7, stagger: 0.15, ease: "power2.out"
  })
  ```

---

**4. Features Grid — 2×2 Asymmetric**
- One card spans 2 columns (featured)
- Featured card includes a real lifestyle image:
  ```
  https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=800 (open photo book)
  ```
- Features: Drag & Drop Editor · 10+ Layouts · PDF Export · Cover Design
- GSAP: `stagger: 0.1` scroll reveal per card

---

**5. Themes Showcase — "Made for Every Memory"**
- 3 large portrait cards `(360×480px)`, slight alternating rotation: `-1.5deg / 0deg / 1.5deg`
- Real themed images:
  ```
  https://images.unsplash.com/photo-1511285560929-80b456fea0bc?w=600 (wedding)
  https://images.unsplash.com/photo-1500835556837-99ac94a94552?w=600 (travel)
  https://images.unsplash.com/photo-1484665754804-74b091211472?w=600 (family)
  ```
- Label badge bottom-left of each card: Azeret Mono 11px, black bg, white text
- GSAP: cards animate in with `rotation: 0` from their skewed initial state

---

**6. Full-Bleed Quote / Brand Statement**
- Background: `#1A1A1A`
- Centered, Cormorant Garamond italic 64px, `color: #F7F5F2`:
  > *"Every photo tells a story.*
  > *We give it a cover."*
- GSAP: text split into words, stagger reveal `0.05s` each using `SplitText` or manual word spans

---

**7. Pricing CTA Banner**
- Background `#C8A882`, full-bleed
- Left: Cormorant Garamond 56px *"Start from EGP 299"*
- Right: black square button `[Create your book →]`
- Border-top + border-bottom: `2px solid #1A1A1A`

---

**8. Footer**
- 3 columns: Brand + tagline | Nav links | Social links
- Border-top `1px solid #1A1A1A`
- Syne 13px, all muted

---

### ⚙️ GSAP Setup
```js
// Install
npm install gsap

// Import
import gsap from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"
gsap.registerPlugin(ScrollTrigger)

// Hero text line-by-line stagger
gsap.from(".hero-line", {
  y: 80, opacity: 0, duration: 1,
  stagger: 0.12, ease: "power4.out", delay: 0.3
})

// Marquee image strip
gsap.to(".marquee-track", {
  x: "-50%", duration: 20,
  ease: "none", repeat: -1
})

// Scroll reveals (apply to all sections)
gsap.utils.toArray(".reveal").forEach(el => {
  gsap.from(el, {
    scrollTrigger: { trigger: el, start: "top 80%", once: true },
    y: 50, opacity: 0, duration: 0.8, ease: "power2.out"
  })
})
```

---

### 🔧 Tech Stack
- **Framework:** Next.js 14 App Router
- **Animations:** `gsap` + `gsap/ScrollTrigger`
- **3D:** `@splinetool/react-spline` (placeholder div if not configured)
- **Images:** Unsplash direct URLs (all specified above)
- **Fonts:** Google Fonts — Cormorant Garamond, Syne, Azeret Mono
- **Styling:** CSS Modules or Tailwind utility-only (no component libraries)

---

### ❌ Hard Avoids
- Inter, Plus Jakarta, Space Grotesk, Roboto
- Glassmorphism, rounded cards, gradient blobs
- Purple/blue color schemes
- shadcn, MUI, Chakra, or any UI kit components
- Stock hero layouts with centered gradient text